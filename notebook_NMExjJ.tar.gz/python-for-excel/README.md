# Python for Excel (O'Reilly, 2021)

<img src="https://github.com/fzumstein/python-for-excel/blob/1st-edition/images/cover.png?raw=true" width="350">

This is the companion repository for the O'Reilly book [Python for Excel](https://learning.oreilly.com/library/view/python-for-excel/9781492080992/).

All notebooks can be run in the cloud except `ch09.ipynb` (requires a local installation of Excel):  
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/fzumstein/python-for-excel/1st-edition)
